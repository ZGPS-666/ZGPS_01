################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Drivers/hexapod/hexapod_control.c \
../Drivers/hexapod/hexapod_remote_control.c \
../Drivers/hexapod/kinematics.c \
../Drivers/hexapod/robot_initialization.c \
../Drivers/hexapod/sbus.c \
../Drivers/hexapod/servo.c \
../Drivers/hexapod/servo2.c \
../Drivers/hexapod/sphere_control.c 

OBJS += \
./Drivers/hexapod/hexapod_control.o \
./Drivers/hexapod/hexapod_remote_control.o \
./Drivers/hexapod/kinematics.o \
./Drivers/hexapod/robot_initialization.o \
./Drivers/hexapod/sbus.o \
./Drivers/hexapod/servo.o \
./Drivers/hexapod/servo2.o \
./Drivers/hexapod/sphere_control.o 

C_DEPS += \
./Drivers/hexapod/hexapod_control.d \
./Drivers/hexapod/hexapod_remote_control.d \
./Drivers/hexapod/kinematics.d \
./Drivers/hexapod/robot_initialization.d \
./Drivers/hexapod/sbus.d \
./Drivers/hexapod/servo.d \
./Drivers/hexapod/servo2.d \
./Drivers/hexapod/sphere_control.d 


# Each subdirectory must supply rules for building sources it contributes
Drivers/hexapod/%.o Drivers/hexapod/%.su Drivers/hexapod/%.cyclo: ../Drivers/hexapod/%.c Drivers/hexapod/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F407xx -c -I../Core/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -I"../Drivers/hexapod" -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Drivers-2f-hexapod

clean-Drivers-2f-hexapod:
	-$(RM) ./Drivers/hexapod/hexapod_control.cyclo ./Drivers/hexapod/hexapod_control.d ./Drivers/hexapod/hexapod_control.o ./Drivers/hexapod/hexapod_control.su ./Drivers/hexapod/hexapod_remote_control.cyclo ./Drivers/hexapod/hexapod_remote_control.d ./Drivers/hexapod/hexapod_remote_control.o ./Drivers/hexapod/hexapod_remote_control.su ./Drivers/hexapod/kinematics.cyclo ./Drivers/hexapod/kinematics.d ./Drivers/hexapod/kinematics.o ./Drivers/hexapod/kinematics.su ./Drivers/hexapod/robot_initialization.cyclo ./Drivers/hexapod/robot_initialization.d ./Drivers/hexapod/robot_initialization.o ./Drivers/hexapod/robot_initialization.su ./Drivers/hexapod/sbus.cyclo ./Drivers/hexapod/sbus.d ./Drivers/hexapod/sbus.o ./Drivers/hexapod/sbus.su ./Drivers/hexapod/servo.cyclo ./Drivers/hexapod/servo.d ./Drivers/hexapod/servo.o ./Drivers/hexapod/servo.su ./Drivers/hexapod/servo2.cyclo ./Drivers/hexapod/servo2.d ./Drivers/hexapod/servo2.o ./Drivers/hexapod/servo2.su ./Drivers/hexapod/sphere_control.cyclo ./Drivers/hexapod/sphere_control.d ./Drivers/hexapod/sphere_control.o ./Drivers/hexapod/sphere_control.su

.PHONY: clean-Drivers-2f-hexapod

