Drivers/hexapod/kinematics.o: ../Drivers/hexapod/kinematics.c
